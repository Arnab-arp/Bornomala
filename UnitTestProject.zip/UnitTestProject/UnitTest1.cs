﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OnlineShoppingStore.DAL;
using OnlineShoppingStore.Models.Home;
using System;
using System.Collections.Generic;

namespace UnitTestProject
{
    [TestClass]
    public class AddToCartTest
    {
        [TestMethod]
        public void CanAddToCart()
        {
            List<Item> cart = new List<Item>();
            Tbl_Product product = new Tbl_Product
            {
                ProductId = 1,
                ProductName = "Your Product Name",
                CategoryId = 2,
                IsActive = true,
                IsDelete = false,
                CreatedDate = DateTime.Now,
                ModifiedDate = DateTime.Now,
                ProductImage = "product_image.jpg",
                IsFeatured = true,
                Quantity = 10,
                Price = 99.99m
            };
            cart.Add(new Item()
            {
                Product = product,
                Quantity = 1
            });

            Assert.IsNotNull(cart);
            Assert.AreEqual(1, cart.Count);
        }
    }
}
